function [ g, p, settings ] = PSOpy_extendedV2( f , search_bounds, param_types, C, W, ObjT, pop_size, N, pareto_p, init_pts)
%%
% Matlab port of Particle Swarm Optimization made in Python
% Universal Modular Version
%
% Usage:
%
% [globbest_fitness, globbest_position, N]=PSOpy(f, dimensions, a, b, N, pop_size)
%
% Inputs:
%       o f  - The objective function.  Pass with @function into here
%       o dimensions  - How many dimensions is the objective function?
%       o a  - Lower bound of search space
%       o b  - Upper bound of search space
%       o N  - Numer of iterations (optional, defaults to 100)
%       o pop_size  - Size of swarm of particles
%       o show_progress  - Show a graph? (2D functions ONLY)
%
% Outputs:
%       o globbest_fitness  - best function value obtained
%       o globbest_position  - best particle position
%       o N  - Iterations.  Shows default if none specified
%
%%

% Some constants for velocity updating
% Local and Global 'correction factors'
c1 = C(1); c2 = C(2);
%c1 = 2.1;
%c2 = 2;
settings.C = C;
settings.W = W;
settings.ObjT = ObjT;
settings.MaxIterations = N;
settings.ParetoPercentage = pareto_p;
% Get dimensions (NEED TO CHANGE IF NOT ALL VARS HAVE BOUNDS)
dimensions = length(search_bounds);

% Weight factors for outputs
%w1 = W(1); w2 = W(2); % Fix

% Percentage to show up on Pareto Front
%pareto_p = .8;

% Modifications to objective type: (since program minimizes)
%ObjT1 = 1;%-1; % Since we want to max, not min
%ObjT2 = -1;%1; % Keep as 1 to minimize Density (second output param)

num_responses = length(W);
% Error criterion for known functions (ignore/unused)
err_crit = 0.00001;

% Initialize the particles
p.pos = zeros(pop_size,dimensions);% 'x values' (pos) for each particle
% Note for below: only need 'dimensions' rows because matlab vertcat issues
p.fitness = zeros(pop_size,1);% evaluated values for each particle
p.v = zeros(pop_size,dimensions);% velocit of each particle
p.bestpos = zeros(pop_size,dimensions);% best position for each particle

% Do random or given initial start?
% If initial start isn't given, init to random
if nargin<=9 || isempty(init_pts)
    for i = 1:pop_size
        % FOR each particle in swarm, init randpos in search space
        
        for j = 1:dimensions
            a = search_bounds(1,j);
            b = search_bounds(2,j);
            ppostemp(i,j) = (b-a).*rand(1,1) + a;
            %a = search_bounds(1,1), b = search_bounds(2,1)
            %ppos(i,:) = (b-a).*rand(1,dimensions) + a;
        end
        p.pos(i,:) = filterFeasibleV2(ppostemp(i,:), search_bounds, param_types, 'Hard');
    end
    p.randominit = p.pos;
else
    for i = 1:pop_size
        p.pos(i,:) = init_pts;%(b-a).*rand(1,dimensions) + a;
    end
end

%%% NOTE: the fitness elements are a bit weird.  Because it is desireable
%%% to group all globalbests together, they are the same size as position
%%% and velocity, although the rest will be zeros. Unless num output vars
%%% is equal to num input vars (dimensions)

% let the first particle be the global best
%gbest = [ppos(1,:); pfitness(1,:); pv(1,:)];          
%             for k = 1:num_objectives
%                 g.bestobj(k) = Objectives.(ObjFields{k})
%             end
g.bestpos = p.pos(1,:);
g.bestfitness = p.fitness(1);
g.bestvelocity = p.v(1,:);

err = 999999999; % Error, ignore it

progress = 0;
disp('Progress: 0%')
disp('[..........]')
i = 0;
while( i < N )
    % While less than itneration max
    
    % For each particle
    for j = 1:pop_size
        if i == 0
            % If first run, get a baseline
            %fitness(:) = f(ppos(j,:)); %some fitness = evalfuncat some xparams
            [Objectives, ~, NonObjectives] = f(p.pos(j,:));
            num_objectives = length(fields(Objectives));
            num_nonobjectives = length(fields(NonObjectives));
            ObjFields = fields(Objectives);
            NonObjFields = fields(NonObjectives);
            for k = 1:num_objectives
                base_response(k) = Objectives.(ObjFields{k});
            end
            %Ex = base_Ex; Density = base_Density;
            %WARNING: This will need to be changed around when constraints
            %added
            for k = 1:num_responses
                fitmat(k) = W(k)*ObjT(k)*base_response(k)/base_response(k);
            end
            %fitness = w1*ObjT1*base_Ex/base_Ex + w2*ObjT2*base_Density/base_Density;
            fitness = sum(fitmat);
            
        else
            % Else runs, use baseline to normalize
            %[Ex, Density] = f(ppos(j,:));
            %fitness = w1*ObjT1*Ex/base_Ex + w2*ObjT2*Density/base_Density;           
            [Objectives, ~, NonObjectives] = f(p.pos(j,:));
            for k = 1:num_objectives
                response(k) = Objectives.(ObjFields{k});
            end
            %Ex = base_Ex; Density = base_Density;
            %WARNING: This will need to be changed around when constraints
            %added
            for k = 1:num_responses
                fitmat(k) = W(k)*ObjT(k)*response(k)/base_response(k);
            end
            %fitness = w1*ObjT1*base_Ex/base_Ex + w2*ObjT2*base_Density/base_Density;
            fitness = sum(fitmat);
        end
        
        
        %fitness(:) = optimizationInputFunction(ppos(j,:))
        % Put storage of nonobj in here and group
        %%% UNPAUSE HERE GOING TO LUNCH %%% 
        if fitness > p.fitness(j,1:length(fitness)) % if this fitness better than particle fitness
            p.fitness(j) = fitness; % update the particle fitness
            
            % Record all shit in particle's 'properties'
            for k = 1:num_objectives
                %p.properties(j,k) = Objectives.(ObjFields{k});
                p.properties(j).(ObjFields{k}) = Objectives.(ObjFields{k});
            end
            for k = 1:num_nonobjectives%num_objectives+1:num_nonobjectives+num_objectives
                %p.properties(j,k) = NonObjectives.(NonObjFields{k-num_objectives});
                p.properties(j).(NonObjFields{k}) = NonObjectives.(NonObjFields{k});
            end
            % Including the fitness that led to it
            p.properties(j).fitness = fitness;
            
            % And the position
            p.properties(j).position = p.pos(j,:);
            %pproperties(j,2:3) = [Ex, Density];
            p.bestpos(j,:) = p.pos(j,:); % update particle's best POS with this value
            %%%CURRENTLY FIXING%%%
            %plot(pparams(1,1),pparams(1,2),'.')
            %text(pparams(1,1),pparams(1,2),num2str(j), 'Position', [pparams(1,1)+.1, pparams(1,2)+.1])
        end
        
        if fitness > g.bestfitness%gbest(2,1:length(fitness)) % if this fitness better than groups'
            %gbest = p % update group best
            %gbest = [ppos(j,:); pfitness(j,:); pv(j,:)];
            g.bestpos = p.pos(j,:);
            g.bestfitness = p.fitness(j);
            g.bestvelocity = p.v(j,:);
            
            for k = 1:num_objectives
                %g.bestproperties(k) = Objectives.(ObjFields{k});
                g.bestproperties.(ObjFields{k}) = Objectives.(ObjFields{k});
            end
            
            for k = 1:num_nonobjectives
                %g.bestproperties(k) = NonObjectives.(NonObjFields{k-num_objectives});
                g.bestproperties.(NonObjFields{k}) = NonObjectives.(NonObjFields{k});
            end
            g.bestproperties.fitness = fitness; % Or p.fitness.. should be same thing
            g.bestproperties.position = p.pos(j,:);
            %best_Ex = Ex; 
            %best_Dens = Density;
            
            %plot(ppos(1,1),ppos(1,2),'rx')
            %text(ppos(1,1),ppos(1,2),num2str(i), 'Position', [ppos(1,1)+.1, ppos(1,2)+.1])
            %text(pparams(1,1),pparams(1,2),num2str(j), 'Position', [pparams(1,1)+.1, pparams(1,2)+.1])
        end
        
        % Try K from:
        %http://web.itu.edu.tr/etaner/ea11.pdf
        phi = c1 + c2;
        K = 2/abs(2-phi-sqrt(phi^2-4*phi));
        % Update velocity
        %v = pv(j,:) + c1.*rand(1,dimensions).*(pbest(j,:)-ppos(j,:)) + c2.*rand(1,dimensions).*(gbest(1,:) - ppos(j,:));
        %pv(j,:) = pv(j,:) + c1.*rand(1,dimensions).*(pbest(j,:)-ppos(j,:)) + c2.*rand(1,dimensions).*(gbest(1,:) - ppos(j,:));
        p.v(j,:) = K*(p.v(j,:) + c1.*rand(1,dimensions).*(p.bestpos(j,:)-p.pos(j,:)) + c2.*rand(1,dimensions).*(g.bestpos - p.pos(j,:)));
        
        % Update position
        %ppos(j,:) = ppos(j,:) + v;
        % Update position with feasible options
        %pposUnfiltered(j,:) = ppos(j,:) + v;o
        %ppostest(j,:) = pposUnfiltered(j,:);
        %ppostest(j,:) = filterFeasible(pposUnfiltered(j,:), search_bounds, 'Hard');
        %ppos(j,:) = filterFeasible(ppos(j,:) + v, search_bounds, 'Hard');
        p.pos(j,:) = filterFeasibleV2(p.pos(j,:) + p.v(j,:), search_bounds, param_types, 'Hard');
    end
    
    
    if err < err_crit
        break
    end
    %progress bar. '.' = 10%
    if (mod(i,(N/10)) == 0)
        progress = progress+1;
        progressBar(progress)
    end
    i  = i+1;
    
end

%globbest_fitness = gbest(2,1:length(fitness));
%globbest_position = gbest(1,:);
%pfitnessout = pfitness(:,1);
%particle_fitness = pfitness(:,1:length(fitness));

%% Get points that made the cut to belong on Pareto Front and plot %%
%pareto_cut_index = 0;
figure()
hold on
% Since we can only visualize 2-3 variables, this is hardcoded
for j = 1:pop_size
    p.properties(j).Pareto = 0; % Create new parameter for each particle
    if p.properties(j).fitness >= pareto_p*g.bestfitness
        %pareto_cut_index = pareto_cut_index + 1;
        %pareto_cut(pareto_cut_index,:) = pproperties(i,:);
        plot(p.properties(j).Ex,p.properties(j).Density,'x')
        p.properties(j).Pareto = 1;
    end
end
plot(base_response(1), base_response(2), 'r.')
plot(g.bestproperties.Ex, g.bestproperties.Density, 'g.')
%plot(base_Ex, base_Density, 'r.')
%plot(best_Ex, best_Dens, 'g.')
hold off
xlabel('Ex')
ylabel('Density')
%plot(pareto_cut(:,2), pareto_cut(:,3))

%% Local functions


    function progressBar(progress)
        switch progress
            case 1
                disp('[|.........]')
            case 2
                disp('[||........]')
            case 3
                disp('[|||.......]')
            case 4
                disp('[||||......]')
            case 5
                disp('[|||||.....]')
            case 6
                disp('[||||||....]')
            case 7
                disp('[|||||||...]')
            case 8
                disp('[||||||||..]')
            case 9
                disp('[|||||||||.]')
            case 10
                disp('[||||||||||]')
                disp('Progress: 100%!')
            otherwise
                disp('progressBar Error: Invalid percentage')
        end
    end


end



